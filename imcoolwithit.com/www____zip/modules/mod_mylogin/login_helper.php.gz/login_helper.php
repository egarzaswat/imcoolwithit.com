<?php

defined('_JEXEC') or die;

class ModMyLoginHelper
{
	public static function getTypeForm(){

    }

}
