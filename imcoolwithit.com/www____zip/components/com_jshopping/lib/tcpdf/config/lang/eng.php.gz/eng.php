<?php
/**
* @license      GNU/GPL
*/
defined('_JEXEC') or die('Restricted access');
// ENGLISH
$l = Array();

// PAGE META DESCRIPTORS

$l['a_meta_charset'] = "UTF-8";
$l['a_meta_dir'] = "ltr";
$l['a_meta_language'] = "en";

// TRANSLATIONS
$l['w_page'] = "page";
?>