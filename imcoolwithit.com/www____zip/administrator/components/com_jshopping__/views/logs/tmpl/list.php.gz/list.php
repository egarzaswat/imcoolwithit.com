<?php
/**
* @version      4.10.0 13.08.2013
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/ 
defined('_JEXEC') or die();
$rows = $this->rows;
?>
<div id="j-sidebar-container" class="span2">
    <?php echo $this->sidebar; ?>
</div>
<div id="j-main-container" class="span10">
<?php displaySubmenuOptions();?>
<form action = "index.php?option=com_jshopping&controller=logs" method = "post" name = "adminForm">
<?php print $this->tmp_html_start?>
<table class="table table-striped">
<thead>
<tr>
    <th class="title" width="10"> # </th>    
    <th align = "left"><?php echo _JSHOP_TITLE;?></th>
    <th align = "left"><?php echo _JSHOP_DATE;?></th>
    <th align = "left"><?php echo _JSHOP_SIZE;?></th>
</tr>
</thead>
<?php foreach($rows as $file){?>
  <tr class = "row<?php echo $i % 2;?>">
   <td>
     <?php echo $i + 1;?>
   </td>
   <td>    
    <a href = "index.php?option=com_jshopping&controller=logs&task=edit&id=<?php echo $file[0];?>"><?php echo $file[0];?></a>
   </td>
   <td><?php print date('Y-m-d H:i:s', $file[1])?></td>
   <td><?php print $file[2]?></td>
  </tr>
<?php
$i++;
}
?>
</table>
<input type = "hidden" name = "task" value = "" />
<input type = "hidden" name = "hidemainmenu" value = "0" />
<input type = "hidden" name = "boxchecked" value = "0" />
<?php print $this->tmp_html_end?>
</form>
</div>