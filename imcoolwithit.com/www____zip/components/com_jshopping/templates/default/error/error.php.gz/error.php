<?php 
    defined('_JEXEC') or die('Restricted access');
?>

<div class="error-page col-sm-8 col-sm-offset-2 col-xs-12">

    <div class="page-content row">

        <h1 class="title"><?php print JText::_('ERROR_PAGE'); ?></h1>

        <div class="text">
            <span><?php print JText::_('ERROR_TEXT_1'); ?></span>
            <span><?php print JText::_('ERROR_TEXT_2'); ?></span>
        </div>

    </div>

</div>