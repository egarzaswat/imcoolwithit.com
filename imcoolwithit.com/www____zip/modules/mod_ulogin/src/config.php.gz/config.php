<?php

$config['callback_url']         =   'http://' . $_SERVER['SERVER_NAME'];

//Facebook configuration
$config['App_ID']      =   '1618118001736353';
$config['App_Secret']  =   '239e5c5f559c40b1d9dfff960c26087c';
/*
$config['App_ID']      =   '555433471263876';
$config['App_Secret']  =   'fcde55c54fb110225878df98c3295eff';*/

?>