<?php
    defined('_JEXEC') or die('Restricted access');
    $userBookmarks = $this->userBookmarks;
    $message = $this->message;
?>

<span>
    <h2><?php echo JText::_('My bookmarks'); ?><h2>
</span>

<div class="userBookmarks">

    <div style="clear:both"></div>

</div>